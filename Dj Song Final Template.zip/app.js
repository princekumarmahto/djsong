// Load songs and render lists/detail
async function loadSongs() {
  let res = await fetch('songs.json');
  return await res.json();
}

function getParam(name) {
  const url = new URL(window.location.href);
  return url.searchParams.get(name);
}

document.addEventListener("DOMContentLoaded", async () => {
  const songs = await loadSongs();

  // index.html
  if(document.getElementById('songs-list')) {
    const list = document.getElementById('songs-list');
    songs.forEach(s => {
      list.innerHTML += `
     
        












 


<div>
  	  	<div align="left"><b><font color="deeppink">	
${s.category}:-</font> <a href="song.html?slug=${s.slug}"><span style="color:#008000;">${s.title} [Download Now]</span></a></b></div></div>
  



       
      `;
    });
  }

  // category.html
  if(document.getElementById('category-list')) {
    const cat = getParam('name');
    document.getElementById('cat-title').innerText = cat + ' Songs';
    const list = document.getElementById('category-list');
    songs.filter(s=>s.category===cat).forEach(s => {
      list.innerHTML += `
      


   	<div class="fl even">
		<a class="fileName" href="song.html?slug=${s.slug}"><div><div><img class="flThumb" alt="cover" src="${s.cover}" width="70" height="70" /></div><div>${s.title}<br/><span>${s.size}</span> </div></div></a>	</div>
	




`;
    });
  }




  // song.html
  if(document.getElementById('song-detail')) {
    const slug = getParam('slug');
    const song = songs.find(s=>s.slug===slug);
    if(song) {
      document.getElementById('song-detail').innerHTML = `
       




    
     <p class="showimage"><img alt="cover" class="absmiddle" src="${song.cover}" width="200" height="200" /></p>
        

   
	

    

     <tr>
       <div class="fl even"><tr class="kpb-table-head p-1 border-light border-bottom"><td><strong>Track</strong></td><td>:-   ${song.title}</td>
      </tr></div>



       
  <tr>
    <div class="fl odd"><tr class="kpb-table-head p-1 border-light border-bottom"><td><strong>Size</strong></td><td>:-   ${song.size} </td>
      </tr></div>
  <div class="fl even"><tr class="kpb-table-head p-1 border-light border-bottom"><td><strong>Added on</strong></td><td>:-   ${song.time} </td>
      </tr></div>

      
  
	
<div class="tCenter">
<h2>Select Download Format</h2>
			<div><audio controls preload="metadata" controlsList="nodownload">
					<source src="${song.file}">
				</audio>
		</div>
				<a class="dwnLink1" rel="nofollow" title="Download Now" href="${song.file}">Download Now</a>	</div>
     





 `;
    }
  }
});