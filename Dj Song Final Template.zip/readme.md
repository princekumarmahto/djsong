# DJ Remix Flat Site
Simple DJ Remix demo site for Cloudflare Pages.

- index.html : Home page listing all songs
- category.html : Songs filtered by category
- song.html : Single song detail with player and download
- app.js : Handles JSON rendering
- style.css : Styling
- songs.json : Data of songs
- assets/images/dj-remix-cover.png : Common cover image
